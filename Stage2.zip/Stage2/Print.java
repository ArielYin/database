/*print the table and record as well as the hints*/
import java.util.*;

class Print{
    //print table
    void printTable(Table t){
        int maxStringLength = t.getMaxStringLengthInTable();
        for(int i = 0; i < t.countRow(); i++){
            Record temp = t.selectRecord(i);
            for(int j = 0; j < temp.getLength(); j++){
                String tempStr = temp.getString(j);
                System.out.printf(tempStr);
                for(int k =0; k < maxStringLength-tempStr.length(); k++){
                    System.out.printf(" ");
                }
            }
            System.out.printf("\n");
       }
    }

    //print record
    void printRecord(Record r){
        for(int i = 0; i < r.getLength(); i++){
            String tempStr = r.getString(i);
            System.out.printf("%-20s", tempStr);
        }
        System.out.print("\n");
    }

    //print the hint of field name
    void fieldNameHint(){
        System.out.println("the field name of table:");
    }

    //complain to the user if the column number is too large
    void rowNumHint(){
        System.out.println("please enter a number that less than column lenth");
    }

    //complain to the user if the key of record is same to other existing record in table
    void keyHint(){
        System.out.println("operation fail for same key");
    }

    //complain to the user if the file is not exist
    void fileExist(){
      System.out.println("the file is not exits!");
    }
}
