class Database{

  public static void main(String []args){
      Table animal = new Table();
      Table new_animal = new Table();
      Print p = new Print();


      Record row1 = new Record();

      row1.addString("Fido");
      row1.addString("dogfdgdfd");
      row1.addString("ab123sdrgfbdfgbc");

      Record row2 = new Record();

      row2.addString("Wanda");
      row2.addString("fishbf");
      row2.addString("ef789");

      Record row3 = new Record();

      row3.addString("Wanda");
      row3.addString("cat");
      row3.addString("ab123");

      Record row4 = new Record();

      row4.addString("Fido");
      row4.addString("pig");
      row4.addString("ab123");


      animal.setField(new String[]{"pet_name", "pet_type", "Id"});
      p.fieldNameHint();
      p.printRecord(animal.selectRecord(0));
      animal.addColumn(new String[]{"owner"});
      animal.changeColumn("ownerName",3);
      animal.addRecord(row1);
      animal.addRecord(row2);
      if(animal.updateRecord(1,row4)==false){
          p.keyHint();
      };
      if(animal.updateRecord(2,row4)==false){
          p.keyHint();
      };
      if(animal.insertRecord(1, row3)==false){
          p.keyHint();
      };
      p.printTable(animal);
      animal.removeRecord(2);
      Files f1 = new Files();
      f1.writeTable("aa.txt", animal);
      Files f2 = new Files();
      f2.readin("a.txt", new_animal);
      p.printTable(new_animal);
 }
}
