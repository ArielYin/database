/* class Files enable table to read from a txt file or be write to a txt file,
the record can also be write to a existing txt file */
import java.io.*;
import java.util.*;

class Files{
    //read the data in the txt file into a table
    void readin(String filePath, Table t){
        try{
        File file = new File(filePath);
        Scanner in = new Scanner(file);

        while (in.hasNextLine()){
            String line = in.nextLine();
            String array[] = line.split(";");
            Record r = new Record();
            for (String temp: array) {
                r.addString(temp);
            }
            t.addRecord(r);
        }
        in.close();
        }catch(IOException e){
            e.printStackTrace();
         }
    }

    // write a record to the end of a existing txt file
    boolean writeRecord(String filePath, Record r){
        try{
        File file = new File(filePath);

        if(!file.exists()){
            return false;
        }
        FileWriter fileWritter = new FileWriter(file.getName(), true);

        for(int i = 0; i < r.getLength(); i++){
            String temp = r.getString(i);
            fileWritter.write(temp);
        }

        fileWritter.close();

        }catch(IOException e){
            e.printStackTrace();
        }
        return true;
    }

    //write a table to a txt file, if the file does not exist, creat it
    void writeTable(String filePath, Table t){
        try{
        File file = new File(filePath);

        if(!file.exists()){
            file.createNewFile();
        }

        FileWriter fileWritter = new FileWriter(file.getName());
        for(int i = 0; i < t.countRow(); i++){
            Record temp = t.selectRecord(i);
            for(int j = 0; j < temp.getLength(); j++){
                String tempStr = temp.getString(j);
                fileWritter.write(tempStr);
                fileWritter.write(";");
            }
            //only work in Linux no need to fix
            fileWritter.write("\n");

        }
        fileWritter.close();
        }catch(IOException e){
            e.printStackTrace();
         }
    }

    public static void main(String []args){
        Table animal = new Table();
        Table b = new Table();

        Print p = new Print();
        Print pr = new Print();

        Record row1 = new Record();

        row1.addString("Fidoxcvbdx");
        row1.addString("dog");
        row1.addString("ab123gdfsgtfjhfgggdf");

        Record row2 = new Record();

        row2.addString("Wanda");
        row2.addString("big fish");
        row2.addString("ef789");

        Record row3 = new Record();

        row3.addString("Garfield");
        row3.addString("cat");
        row3.addString("ab123");



        animal.addRecord(row1);
        animal.addRecord(row2);

        animal.setField(new String[]{"pet_name","pet_type", "OwnerId"});
        Files f1 = new Files();
        f1.writeTable("aa.txt", animal);
        Files f3 = new Files();
        f1.writeRecord("aa.txt", row3);

        Files f2 = new Files();
        f2.readin("a.txt", b);
        pr.printTable(b);
        System.out.printf("\n");
        p.printTable(animal);

   }
}
