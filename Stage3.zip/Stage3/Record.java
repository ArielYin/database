/*functions related to a single record*/
import java.util.*;

class Record{
   
    private ArrayList<String> record = new ArrayList<String>();

    //add a new string to the end of record
    void addString(String s){
        record.add(s);
    }

    //get the string in record by specifying index number
    String getString(int index){
        return record.get(index);
    }

    //set(update) a string by specifying index number
    void setString(int index, String s){
        record.set(index,s);
    }

    //get the legth of the record(string number)
    int getLength(){
        return record.size();
    }

    //get the longest string in the record and return its length
    int getMaxStringLength(){
        int init = 0;
        for(int i = 0; i< record.size(); i++){
            String temp = record.get(i);
            if(temp.length() > init){
                init = temp.length();
            }
        }
        return init;
    }

    //remove all the elements of the record
    void removeAll(){
       record.clear();
    }

    //remove a record by row number
    void remove(int index){
        record.remove(index);
    }

    //test
    private void test(){
      this.addString("abc");
      this.addString("def");
      this.addString("ghi");
      assert(this.getString(0).equals("abc"));
      assert(this.getString(1).equals("def"));
      assert(this.getString(2).equals("ghi"));
      this.setString(0,"a");
      assert(this.getString(0).equals("a"));
      assert(this.getString(1).equals("def"));
      this.setString(2,"ghijklnm");
      assert(this.getString(2).equals("ghijklmn"));
      assert(this.getLength()==3);
      assert(this.getMaxStringLength()==8);
      System.out.println("tests ok");
    }
    public static void main(String []args) {
        Record record = new Record();
        record.test();
    }
}
