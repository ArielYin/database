/* class Query include a parse for clauses, realize some functions including list table name, load table, delect table. This class is just a demo to show idea of
query sentence, the input/output interface should be adjust to Print class in the future*/

import java.io.*;
import java.util.*;
class Query{
    private String com1;
    private String com2;
    void parse(Database db){
        Scanner scan = new Scanner(System.in);
        Print p = new Print();
        int flag = 1;
        Table t = new Table();

        while(flag == 1){
            System.out.println("please enter the clauses:");
            System.out.println("->list");
            System.out.println("->load + Table Name");
            System.out.println("->drop + Table Name");
            System.out.println("->quit");
            String line = scan.nextLine();
            //String line1 = line.toLowerCase();
            String newLine = line.replaceAll("\\s+"," ");

            String[] command = newLine.split(" ");
            if(command.length==0){
                return;
            }
            if(command.length>=1){
                com1 = command[0];
                if(com1.equals("list")){
                    db.getKey();
                }else if(com1.equals("load")){
                    com2 = command[1];
                    t = load(com2,db);
                }else if(com1.equals("drop")){
                    com2 = command[1];
                    delect(com2,db);
                }else if(com1.equals("quit")){
                    flag = 0;
                    quit();
                }
               }
           }
        }

    Table load(String s, Database db){
        Print p = new Print();
        p.printTable(db.getTable(s));
        return db.getTable(s);
    }

    void delect(String s,Database db){
        db.delectTable(s);
    }

    void quit(){
        System.out.println("Bye!");
    }

    /*void project(ArrayList<String> s, Table t){
        for(int i = 0; i < s.size(); i++ ){
            t.delectCol(s.get(i));
            Print p = new Print();
            p.printTable(t);
        }
    }*/

    public static void main(String [] array){
        Database db = new Database();
        Query q = new Query();
        Files f = new Files();
        Table animal = new Table();
        Table new_animal = new Table();
        f.readin("new_animal.txt", new_animal);
        f.readin("animal.txt", animal);
        db.addTable("animal", animal);
        db.addTable("new_animal", new_animal);
        q.parse(db);
    }
}
