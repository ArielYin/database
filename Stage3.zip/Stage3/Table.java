/*functions related to table; including the fuctions about the rows in table(records)
and the columns in table(field name)*/
import java.util.*;

class Table{
    private ArrayList<Record> table = new ArrayList<Record>();

    // add a record to table
    void addRecord(Record r){
      String key = r.getString(0);
      for(int i = 0; i < table.size(); i++){
         Record temp = table.get(i);
         if (temp.getString(0)==key){
           return;
         }
      }
      table.add(r);
    }

    //select a record in table by row number
    Record selectRecord(int index){
        return table.get(index);
    }

    //update a record by row number, the key(first column) is also checked when updating
    boolean updateRecord(int index, Record r){
        String key = r.getString(0);
        for(int i = 0; i < table.size(); i++){
           Record temp = table.get(i);
           if (temp.getString(0)==key && i!=index){
             return false;
           }
        }
        table.set(index, r);
        return true;
    }


    //insert a reacord by specifying row number, the key(first column) is checked when inserting
    boolean insertRecord(int index, Record r){
        String key = r.getString(0);
        for(int i = 0; i < table.size(); i++){
            Record temp = table.get(i);
            if (temp.getString(0)==key){
            return false;
         }
      }
        table.add(index, r);
        return true;
    }

    //remove a record by row number
    void removeRecord(int index){
        table.remove(index);
    }

    //count the total row of table
    int countRow(){
        return table.size();
    }

    //find the longest string in the table by checking all records and return string length
    int getMaxStringLengthInTable(){
        int init =0;
        for(int i =0; i < table.size(); i++){
            Record temp = table.get(i);
            int MaxStringLengthInRecord = temp.getMaxStringLength();
            if(MaxStringLengthInRecord > init){
                init = MaxStringLengthInRecord;
            }
        }
        return init;
    }

    //select multiple record by specifying the row number
    ArrayList<Record> selectMultRecord(int [] a){
        ArrayList<Record> collection = new ArrayList<Record>();
        for(int i = 0; i < a.length; i++){
            collection.add(table.get(a[i]));
        }
        return collection;
    }

    //select multiple record by specifying the key value
    ArrayList<Record> selectMultRecordByKey(String [] array){
        ArrayList<Record> collection = new ArrayList<Record>();
        for(String tempStr:array){
            for (int i = 0; i < table.size(); i++){
                Record temp = table.get(i);
                if(temp.getString(0)==tempStr){
                    collection.add(temp);
                }
            }
        }
        return collection;
    }

    //delect multiple record by specifying the row number
    void delectMultRecord(int [] a){
        ArrayList<Record> collection = new ArrayList<Record>();
        for(int i = 0; i < a.length; i++){
            collection.add(table.get(a[i]));
        }
        table.removeAll(collection);
     }

     //delect multiple record by specifying the key value
     void delectMultRecordByKey(String [] array){
       ArrayList<Record> collection = new ArrayList<Record>();
       for(String temp_str:array){
           for (int i = 0; i < table.size(); i++){
               Record temp = table.get(i);
               if(temp.getString(0)==temp_str){
                   collection.add(temp);
               }
           }
       }
       table.removeAll(collection);
     }

    // set the field name of table
    void setField(String []array){
        Record fieldName = new Record();
        //Print p = new Print();
        for (String temp_str: array) {
              fieldName.addString(temp_str);
          }
        table.add(0, fieldName);
    }

    //add new column(s) in table
    void addColumn(String []array){
        Record fieldName = table.get(0);

        for (String temp_str: array) {
              fieldName.addString(temp_str);
          }
        table.set(0, fieldName);
    }

    //change a cloumn name by specifying its colunm number(colum number starts from 1 to n)
    boolean changeColumn(String s, int index){
        Record fieldName = table.get(0);

        if (index > fieldName.getLength()){
            return false;
        }
        fieldName.setString(index-1, s);
        table.set(0, fieldName);
        return true;
    }

    //delect the column name and its contens by specifying the column number (column number starts from 1 to n)
    void delectColumn(int index){
        for(int i=0; i<table.size(); i++){
            table.get(i).remove(index-1);
        }
    }

    //delect the column name and its contents by specifying its column name
    void delectCol(String s){
        int flag = 0;
        Record temp_record = table.get(0);
        for(int i = 0; i < temp_record.getLength(); i++){
            if(s.equals(temp_record.getString(i))){
                delectColumn(i+1);
            }else return;
        }
   }


    //testing
    private void test(){

        Record row1 = new Record();

        row1.addString("Fido");
        row1.addString("dog");
        row1.addString("ab12");

        Record row2 = new Record();

        row2.addString("Wanda");
        row2.addString("big fish");
        row2.addString("ef789");

        Record row3 = new Record();

        row3.addString("Garfield");
        row3.addString("cat");
        row3.addString("ab123");

        Record newrow1 = new Record();

        newrow1.addString("Fido");
        newrow1.addString("bigbig_dog");
        newrow1.addString("ab123");

        Record row4 = new Record();

        row4.addString("Garfield");
        row4.addString("cat");
        row4.addString("ab123");

        //test row functions
        this.addRecord(row1);
        assert(this.selectRecord(0).getString(0).equals("Fido"));
        assert(this.selectRecord(1)==row1);
        this.addRecord(row2);
        assert(this.selectRecord(1).getString(1).equals("big fish"));
        assert(this.updateRecord(0,newrow1));
        assert(this.selectRecord(0).getString(1).equals("bigbig_dog"));
        assert(!this.updateRecord(1,newrow1));
        assert(this.insertRecord(1,row3));
        assert(!this.insertRecord(1,row4));
        assert(this.countRow()==3);
        Print p =new Print();
        p.printTable(this);

        //test columns functions
        this.setField(new String[]{"pet_name", "pet_type", "owner_Id"});
        assert(this.selectRecord(0).getString(0).equals("pet_name"));
        assert(this.selectRecord(0).getString(1).equals("pet_type"));
        assert(this.selectRecord(0).getString(2).equals("owner_Id"));
        this.addColumn(new String[]{"owner_name", "address"});
        assert(this.selectRecord(0).getString(3).equals("owner_name"));
        assert(this.selectRecord(0).getString(4).equals("address"));
        this.changeColumn("owner_address",4);
        assert(this.selectRecord(0).getString(4).equals("owner_address"));
        this.delectColumn(1);
        assert(this.selectRecord(0).getString(0).equals("pet_type"));
        this.delectCol("pet_type");
        assert(this.selectRecord(1).getString(0).equals("ab123"));
        System.out.println(this.selectRecord(1).getString(0));
        //test for mulitple records
        ArrayList<Record> testSelect1 = new ArrayList<Record>() ;
        testSelect1 = this.selectMultRecord(new int[]{0,1});
        assert(testSelect1.get(1)==row2);
        assert(testSelect1.get(1).getString(0).equals("Wanda"));
        ArrayList<Record> testSelect2 = new ArrayList<Record>();
        testSelect2 = this.selectMultRecordByKey(new String[]{"Fido", "Wanda"});
        assert(testSelect2.get(1)==row2);
        assert(testSelect2.get(1).getString(0).equals("Wanda"));

        System.out.println("Table class ok");
    }
    public static void main(String []args){
      Table animal = new Table();
      animal.test();
   }
}
