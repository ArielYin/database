/*class Database contains a hash map, table and its name(key) are stored in the 
map*/
import java.util.*;

class Database{
    Map<String, Table> database = new HashMap<>();
    
    //add table to database
    void addTable(String s, Table t){
        database.put(s, t);
    }
     
    //print all keys as a string
    void getKey(){
        System.out.println(database.keySet().toString());
    }

    //get table by specifying the key 
    Table getTable(String s){
        return database.get(s);
    }

    //delect table by soecifying the key
    void delectTable(String s){
        database.remove(s);
    }
                  
    public static void main(String []args){
        Table animal = new Table();
        Table new_animal = new Table();

        
        Print p = new Print();

        //creat a table by inserting record one by one
        Record row1 = new Record();

        row1.addString("Fido");
        row1.addString("big dog");
        row1.addString("ab123");

        Record row2 = new Record();

        row2.addString("Wanda");
        row2.addString("fish");
        row2.addString("ef789");

        Record row3 = new Record();


        row3.addString("Kitty");
        row3.addString("cat");
        row3.addString("ef789");

        animal.setField(new String[]{"pet_name", "pet_type", "Id"});
        //p.fieldNameHint();
        //p.printRecord(animal.selectRecord(0));

        animal.addRecord(row1);
        animal.addRecord(row2);
        
        p.printTable(animal);
        Files f1 = new Files();
        f1.writeTable("animal.txt", animal);

        //creat a new table by reading from a txt file
        Files f2 = new Files();
        f2.readin("new_animal.txt", new_animal);
        p.printTable(new_animal);
        Database db = new Database();
        db.addTable("animal", animal);
        db.addTable("new_animal", new_animal);
 }
}
