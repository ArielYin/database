import java.io.*;
import java.util.*;

class Files{

    public void readin(String file_path, Table t){
        try{
        File file = new File(file_path);
        Scanner in = new Scanner(file);
        //Record r = new Record();

        while (in.hasNextLine()){
            String line = in.nextLine();
            String array[] = line.split(";");
            Record r = new Record();
            for (String temp: array) {
                r.add_string(temp);
            }
            t.add_record(r);
            r.print_record();
            //r.remove_all();
        }
        in.close();
        }catch(IOException e){
            e.printStackTrace();
         }
    }

    public void writeRecord(String file_path, Record r){
        try{
        File file = new File(file_path);

        if(!file.exists()){
            System.out.println("the file is not exits!");
            return;
        }
        FileWriter fileWritter = new FileWriter(file.getName(), true);

        for(int i = 0; i < r.get_length(); i++){
            String temp = r.get_string(i);
            fileWritter.write(temp);
        }

        fileWritter.close();
        }catch(IOException e){
            e.printStackTrace();
         }
    }

    public void writeTable(String file_path, Table t){
        try{
        File file = new File(file_path);

        if(!file.exists()){
            file.createNewFile();
        }

        FileWriter fileWritter = new FileWriter(file.getName());
        for(int i = 0; i < t.count_row(); i++){
            Record temp = t.select_record(i);
            for(int j = 0; j < temp.get_length(); j++){
                String temp_str = temp.get_string(j);
                fileWritter.write(temp_str);
            }
            //only work in Linux no need to fix
            fileWritter.write("\n");

        }
        fileWritter.close();
        }catch(IOException e){
            e.printStackTrace();
         }
    }

    public static void main(String []args){
        Table animal = new Table();
        Table b = new Table();
        Record row1 = new Record();
        Print p = new Print();
        Print pr = new Print();



        row1.add_string("Fido;");
        row1.add_string("dog;");
        row1.add_string("ab123;");

        Record row2 = new Record();

        row2.add_string("Wanda;");
        row2.add_string("fish;");
        row2.add_string("ef789;");

        Record row3 = new Record();

        row3.add_string("Garfield;");
        row3.add_string("cat;");
        row3.add_string("ab123;");
        /*animal.set_field(animal);*/

        animal.add_record(row1);
        animal.add_record(row2);


        Files f1 = new Files();
        f1.writeTable("aa.txt", animal);
        Files f3 = new Files();
        f1.writeRecord("aa.txt", row3);

        Files f2 = new Files();
        f2.readin("a.txt", b);
        f2.writeTable("b.txt", b);
        pr.print_table(b);
        System.out.printf("\n");
        p.print_table(animal);

   }
}
