import java.util.*;

class Record{
    ArrayList<String> record = new ArrayList<String>();

    public void add_string(String s){
        record.add(s);
        /*System.out.println("add: " + s);*/
    }

    public String get_string(int a){
        String temp = record.get(a);
        /*System.out.println("get the element: " + temp);*/
        return temp;
    }

    public void set_string(int a, String s){
        record.set(a,s);
        System.out.println("the element has been changed to " + s);
    }

    public int get_length(){
        int len = record.size();
        /*System.out.println("the length of this record is: " + len);*/
        return len;
    }

   public void remove_all(){
       record.clear();
   }

   //could all print method be put in Print class?
   public void print_record(){
        System.out.println(record);
   }

    public static void main(String []args) {
        Record record = new Record();

        try{
            record.add_string("asb");
            record.add_string("asf");
            record.set_string(0,"a");
            record.set_string(1,"asc");
            record.get_string(0);
            record.get_length();
        }

        catch (IndexOutOfBoundsException e){
            System.out.println("Exception thrown:" + e);
        }
    }
}
