import java.util.*;

class Print{
    public void print_table(Table t){
        for(int i = 0; i < t.count_row(); i++){
            Record temp = t.select_record(i);
            for(int j = 0; j < temp.get_length(); j++){
                String temp_str = temp.get_string(j);
                System.out.printf("%-10s", temp_str);
            }
            System.out.printf("\n");
       }
    }
}
