import java.util.*;

class Table{
    ArrayList<Record> table = new ArrayList<Record>();

    public void add_record(Record r){
      table.add(r);
      /*System.out.print("add record: ");
      r.print_record();*/
    }

    public Record select_record(int a){
        Record temp = table.get(a);
        /*System.out.println("select the record of row: " + a);*/
        return temp;
    }

    public void update_record(int a, Record r){
        table.set(a, r);
        //System.out.println("the record of row " + a + " has been updated");
    }


    public void insert_record(int a, Record r){
        table.add(a, r);
        //System.out.println("the record has been inserted into row " + a);
    }

    public void remove_record(int a){
        table.remove(a);
        //System.out.println("the record of row " + a+ " has been removed!");
    }

    public int count_row(){
        int row = table.size();
        return row;
    }

    public ArrayList<Record> select_mult_record(int [] array){
        ArrayList<Record> collection = new ArrayList<Record>();
        for(int i = 0; i < array.length; i++){
            int flag = array[i];
            collection.add(table.get(flag));
        }
        return collection;
    }

    public void delect_mult_record(int [] a){
        ArrayList<Record> collection = new ArrayList<Record>();
        for(int i = 0; i < a.length; i++){
            int flag = a[i];
            collection.add(table.get(flag));
        }
        table.removeAll(collection);
     }

    //交互 通过键盘输入field_name
    /*public void set_field(Table t){
        Scanner scan = new Scanner(System.in);
        Record field_name = new Record();
        String a;

        System.out.println("please enter the fields names, press # to end");
        while (!(a = scan.next()).equals("#")){
            field_name.add_string(a);
        }
        t.insert_record(0, field_name);
        System.out.println("the field name of table:");
        (t.select_record(0)).print_record();
    }

    public void add_column(Table t){
        Scanner scan = new Scanner(System.in);
        Record field_name = t.select_record(0);
        String a;

        System.out.println("please enter the fields names you want add, press # to end");
        while (!(a = scan.next()).equals("#")){
            field_name.add_string(a);
        }
        t.update_record(0, field_name);
        System.out.println("new columns has been added!");
        System.out.println("the new field names are: " );
        (t.select_record(0)).print_record();
    }

    public void change_column(Table t){
        Scanner scan = new Scanner(System.in);
        Record field_name = t.select_record(0);

        System.out.println("please enter the column number you want change");
        int n = scan.nextInt();
        if (n > field_name.get_length()){
            System.out.println("please enter a number that less than row lenth");
            return;
        }
        System.out.println("please enter the filed name you want to change to");
        String b = scan.next();
        field_name.set_string(n-1, b);
        t.update_record(0, field_name);
        System.out.println("the column " +n + "has been changed to: ");
        (t.select_record(0)).print_record();
    }*/

    public void set_field(String []array, Table t){
        Record field_name = new Record();
        for (String temp: array) {
              field_name.add_string(temp);
          }
        t.insert_record(0, field_name);
        System.out.println("the field name of table:");
        (t.select_record(0)).print_record();
    }

    public void add_column(String []array,Table t){
        Record field_name = t.select_record(0);
        for (String temp: array) {
              field_name.add_string(temp);
          }
        t.update_record(0, field_name);
        System.out.println("new columns has been added!");
        System.out.println("the new field names are: " );
        (t.select_record(0)).print_record();
    }

    public void change_column(Table t, String s, int a){
        Record field_name = t.select_record(0);
        if (a > field_name.get_length()){
            System.out.println("please enter a number that less than row lenth");
            return;
        }
        field_name.set_string(a-1, s);
        t.update_record(0, field_name);
        System.out.println("the column " + a + " has been changed to: ");
        (t.select_record(0)).print_record();
    }




    public static void main(String []args){
        Table animal = new Table();
        Record row1 = new Record();

        row1.add_string("Fido");
        row1.add_string("dog");
        row1.add_string("ab123");

        Record row2 = new Record();

        row2.add_string("Wanda");
        row2.add_string("fish");
        row2.add_string("ef789");

        Record row3 = new Record();

        row3.add_string("Garfield");
        row3.add_string("cat");
        row3.add_string("ab123");


        animal.add_record(row1);
        animal.add_record(row2);
        animal.insert_record(1, row3);
        System.out.println(animal.select_mult_record(new int[]{0,2}));
        animal.remove_record(2);
        animal.set_field(new String[]{"pet_name", "pet_type", "Id"},animal);
        animal.add_column(new String[]{"owner"},animal);
        animal.change_column(animal, "ownerId",3);
   }





}
